f=open('C:/Users/User/Downloads/customer','r')
for i in f:
   data=i.rstrip("\n").split(",")
   print(data)

 #  age=data[3]
   if(data[3]>'50'):
       print(data[1:5])
print("*****************************************")
#1.age above 50 istname last name,age,prof
