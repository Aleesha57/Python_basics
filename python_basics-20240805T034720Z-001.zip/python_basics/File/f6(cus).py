#each prof count
f = open('C:/Users/User/Downloads/customer', 'r')
dic={}
for k in f:
    data = k.rstrip("\n").split(",")
    print(data)
    prof = data[4]
    if(prof not in dic):
            dic[prof]=1
    else:
            dic[prof]+=1
print(dic)
