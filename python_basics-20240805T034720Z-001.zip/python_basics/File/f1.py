#  3 types of operations
  #read    r,
  # write  w
  #append  a

#file refference

#syntax
#
# file_refference_name=open('argument1','argument2')
# argument1=filepath(which file wat to read or write)
# argument2=mode of opperation
# eg:f=open('sample1','r')