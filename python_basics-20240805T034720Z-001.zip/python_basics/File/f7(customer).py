#each country count
f = open('C:/Users/User/Downloads/customer', 'r')
dic={}
f = open('C:/Users/User/Downloads/customer', 'r')
for k in f:
    data = k.rstrip("\n").split(",")
    loc = data[-1]  #because we get index outofrange
    print(loc)
    if(loc not in dic):
            dic[loc]=1
    else:
            dic[loc]+=1
#print(dic) or
for k,v in dic.items():
    print(k,",",v)
