f=open('C:/Users/User/Downloads/movies','r')
for i in f:
    data=i.rstrip("\n").split(",")
    print(data)
#movie
#1.after 2000 released movie name,yr,rate
#2.1975 and 2000 movies name,year,ratig
#3.rating above4 name,yr,rating
#4.ratiing 3.5 and above 4 name,yr rating
#5.each yr release movie count