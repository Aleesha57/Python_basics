#copy the content excluding apple

f1=open('fruits','r')
f2=open('fruits_ans','w')
for i in f1:
    data=i.rstrip("\n")
    if(data!='apple'):
        f2.write(i)     #to get line by line data we use i instead of data
print(f2)
