f=open('sample1','r')  # if the file is in same package we can use the file name itself
for i in f:
 print(i)