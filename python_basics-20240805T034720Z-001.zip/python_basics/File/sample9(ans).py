#to copy the file content to another
f2=open('sample9','r')
f=open('write_demo(ans)','w')
for i in f2:
   f.write(i)
print(f)