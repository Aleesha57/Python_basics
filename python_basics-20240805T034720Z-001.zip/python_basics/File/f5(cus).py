# us and age>50 fname,lname,AGE,prof,loc
f = open('C:/Users/User/Downloads/customer', 'r')
for k in f:
    data = k.rstrip("\n").split(",")
    loc = data[5]
    age = data[3]
    if loc == 'us' and age > '50':
        print(data[1:])

