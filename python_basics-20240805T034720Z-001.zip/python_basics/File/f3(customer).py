f=open('C:/Users/User/Downloads/customer','r')
#pilot fname lname,age,prof,country
for j in f:
   data=j.rstrip("\n").split(",")
   if(data[4]=='Pilot'):
       print(data[1:6])

print("*****************************")
