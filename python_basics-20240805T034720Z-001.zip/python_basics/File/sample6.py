f=open('sample5','r')
list=[]
for i in f:
    list.append(int(i.rstrip("\n")))  # this is in string so
print(list)  # to avoid \n  rstrip(right side) and lstrip(left side)

print(sum(list))

data='hello\n'
data1=data.rstrip("\n")
print(data1)