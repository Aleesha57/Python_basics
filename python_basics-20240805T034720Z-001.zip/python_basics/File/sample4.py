f=open('G:\PycharmProjectnovSabirBatch\collection\sample3(file)','r')
for i in f:
    print(i)