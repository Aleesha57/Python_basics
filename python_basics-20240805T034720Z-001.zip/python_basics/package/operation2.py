#import packagename.modulename
#variable_name=packagename.modulename.functioncall()

# import package.operation1
# package.operation1.add(12,2)
# package.operation1.div(10,3)


# to overcome above problem

from package.operation1 import*
add(5,6)
sub(3,3)