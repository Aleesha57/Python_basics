def add(num1,num2):

    sum=num2+num1
    print(sum)
def sub(num,num1):

    su= num - num1
    print(su)


def div(num, num1):
    su = num /num1
    print(su)
