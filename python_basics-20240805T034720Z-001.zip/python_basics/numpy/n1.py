#python libaries

#numpy      -
#Scipy(scientific python:integration,log ,differential etc)
#pandas     -
#matplotlib  ------------------------------EDA(Exploratory data analysis)
#seaborn    -



#numpy(numerical python)
    #used in mathematical operation (Linear Algebra)
       #matrics,vector,fourier transform(mainly used in matrics)
    #eg:face recoganition
import numpy as np
a=np.array([1,2,3,4,5,6])
print(a)


#if we create a class in numpy it is called:N diamensional array
lst=(1,2,3,4,5)
print(type(lst))  #class=tuple

#array create

import numpy as np
a=np.array([1,2,3,4,5])#list or tuple or etc...
print(a)


