import numpy as np
a=np.array([[[2,3,4],[4,5,6],[5,6,4],[2,3,4]]])
print(a)
print(a.ndim)
print(a.shape)

#dtype==(to find the data type)
print(a.dtype)

#to convert dtype into float

b=np.array([2,3,4],dtype=float)
print(b)