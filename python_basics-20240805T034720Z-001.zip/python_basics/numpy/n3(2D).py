import numpy as np
a=np.array([[2,3,4],[3,4,6],[3,4,5]])
print(a.ndim)
print(a.shape)

#4*4

b=np.array([[2,3,4,5],[4,7,3,2],[3,2,9,5],[4,6,8,3]])
print(b)
print(b.ndim)
print(b.shape)

#size=total no.of elements
  #no. of rows * no. of columns
    #(3*4)==12
    #(4*2)=8
print(a.size)