import numpy as np
a=np.array([2,33,4,56])
b=np.array([2,33,12,6])
c=np.dot(a,b)
# [2             [2
#  33             33
#  4              12
#  56]            6]

#[2*2+33*33+4*12+56*6]  for  1D
print(c)