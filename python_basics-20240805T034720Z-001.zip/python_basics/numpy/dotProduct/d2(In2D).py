import numpy as np
a=np.array([[3,4,5],[45,6,7],[33,45,2]])
b=np.array([[3,12,5],[6,12,7],[7,4,21]])
#dot

c=np.dot(a,b)
print(c)
