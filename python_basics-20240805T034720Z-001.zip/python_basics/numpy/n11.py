#(4*6)  to (6*4) then to (12*2)

import numpy as np
a=np.array([[4,5,6,7],[5,6,8,9],[23,4,55,6],[4,5,6,7],[7,4,34,5],[4,5,6,7]])
b=a.reshape([6,4])
print(b)
c=b.reshape([12,2])
print(c)