#zero matrix

#[0 0]
#[0 0]..

#zeros== to create zero matrix
import numpy as np
a=np.zeros([3,4],dtype=int)  #this is the order of the matrix
print(a)

b=np.zeros([6,])
print(b)

#3D zero matrix
print("**********************************************")

c=np.zeros([2,3,2],dtype=int)
print(c)
print("####################################################")

d=np.zeros([1,3,2],dtype=int)
print(d)