#2D to 1D
import numpy as np
a=np.array([[3,4,5],[5,23,4],[8,7,3],[12,4,3]])
print(a)

b=a.reshape([12])
print(b)