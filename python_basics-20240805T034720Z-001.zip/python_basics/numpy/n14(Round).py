#round floor ceil

#4*4
import numpy as np
a=np.array([[3.5,4.23,5,8],[45.2,12.12,6.75,5.5],[3.62,3,4.5,2.33]])
b=np.array([[3,12,5,3],[6,12,1,7],[3,52,4,21]])

#Floor:to discard decimal part
d=np.floor(a)
#1.2=1  2.3=2
print(d)
#ceil:convert into highest interger
#1.2=2   1.01=2  2.3=3  etc

c=np.ceil(a)
print(c)

#round
  #above .5 ====highest
  #below .5 =====lowest
#if it is .5 even lowest odd=highest
e=np.round(a)
print(e)