#diamension

# 1D  ====>onne axis ==>x
# 2D  ====>2 axis ===>x,y
# 3D  ====>3 axis ===>z,x,y(not x,y,z)

#number of axis

import numpy as np
a=np.array([2,3,5,4,8])
print(a)
print(a.shape) #if it is 1D elements will read as row row....

#ndim  ====>to get the diamension
print(a.ndim)

#2D
#order ==(number of rows * no of column)

# [3 5 4 8]    [4 5 4]     [1 7 5 9]
# [5 4 5 9]    [6 8 2]      order=(1*4)
# [3 3 6 9]    [3 4 2]
# order=(3*4)  order=(3*3)

b=np.array([[3,4,5,6],[4,3,5,6],[3,6,2,5]])
print(b)
print(b.ndim)
#shape === to find the order
print(b.shape)