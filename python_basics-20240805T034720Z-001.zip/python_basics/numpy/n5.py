#(2*3) dtype=float

import numpy as np
a=np.array([[4,2],[8,4],[8,12]],dtype=float)
print(a)
