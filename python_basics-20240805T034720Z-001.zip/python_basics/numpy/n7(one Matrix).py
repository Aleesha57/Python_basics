#one matrix
 #ones

import numpy as np
a=np.ones([2,3])
print(a)
#1D,3D
print("************************************")
b=np.ones([5,])
print(b)
print(b.ndim)
c=np.ones([1,4,4])
print(c)
print(c.ndim)