#full matrix

# [3 3 3]
# [3 3 3]
# [3 3 3]

import numpy as np
a=np.full([3,4],3)
print(a)
print("question2.")
#1D total==10 7 fill
b=np.full([10,],7)
print(b)
