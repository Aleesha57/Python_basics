import numpy as np
a=np.array([3,4,5,6,35,12,49,7,12])
print(a)
b=np.argsort(a)  # index of the elements in sorted order
print(b)
#2D
print("2D\n")
c=np.array([[3,4,5,6],[23,45,6,7],[7,33,45,2],[3,4,7,9]])
print(c)
e=np.sort(c)
d=np.argsort(c)
print(e)
print(d)
f=np.sort(c,axis=0)
print(f)
g=np.argsort(c,axis=0)
print(g)