import numpy as np
a=np.array([3,4,5,6,35,12,49,7,12])

#sort
b=np.sort(a)
print(b)

#decending order

c=np.sort(a)[::-1]
print(c)

#2D
d=np.array([[3,4,5,6],[23,45,6,7],[7,33,45,2],[3,4,7,9]])
e=np.sort(d)  #sorting in row vise
f=np.sort(d,axis=0)
print(e)
print(f)