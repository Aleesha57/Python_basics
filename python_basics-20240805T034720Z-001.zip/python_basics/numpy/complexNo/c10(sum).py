import numpy as np
a=np.array([3,4,5,6])
b=np.sum(a)
print(b)

#2D
c=np.array([[3,12,5],[6,12,7],[3,4,21]])
d=np.sum(c)
print(d)
e=np.sum(c,axis=0) #column wise sum
print(e)
f=np.sum(c,axis=1) #rowwise suum
print(f)


#axis=0, axis=1