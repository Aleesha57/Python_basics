#complex matrics or complex number mtrics

#1.real part
#2.imaginary part
#  a+ib   2+4j
import numpy as np
a=np.ones([3,4],dtype=complex)
print(a)