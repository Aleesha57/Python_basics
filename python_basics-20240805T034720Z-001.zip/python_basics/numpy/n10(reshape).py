#2d (3*4)

import numpy as np
a=np.array([[3,4,5],[5,23,4],[8,7,3],[12,4,3]])
print(a)
#reshape==to change the order (ie 3*4) to (4*3)
b=a.reshape([4,3])
print(b)
# c=a.reshape([3,3]) #it cant bcz total no.of elements should be same
# print(c)

d=a.reshape([2,6])
print(d)