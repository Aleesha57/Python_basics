#2d (4*4)

import numpy as np
a=np.array([[3,9,4,5],[5,2,3,4],[8,9,7,3],[1,2,4,3]])
print(a)
#(4*4)   ==(2*8),8*2

#1D  flatten

b=a.flatten()
print(b)