#identity matrix

#diagonal element ==1 and remaining elements are zero(it should be a square matrix)
# [1 0 0]
# [0 1 0]
# [0 0 1]

#identity,eye funtion
import numpy as np
a=np.identity(3)
print(a)
b=np.eye(2)
print(b)