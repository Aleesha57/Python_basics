#addition,su,div,mult
#enter ur chice

def add(a, b):
    sum = a + b
    return sum


def sub(a, b):
    su = a - b
    return su


def mult(a, b):
    m = a * b
    return m


def div(a, b):
    d = a / b
    return d


print("1.addition"
       "2.substraction"
       "3.multiplication"
       "4.division")
ch=int(input("enter your choice:"))
num1=int(input("enter the 1st number:"))
num2=int(input("enter the 2nd number:"))
if(ch==1):

    print(num1,"+",num2,"=",add(num1,num2))
elif(ch==2):
    print(num1,"-",num2,"=",sub(num1,num2))
elif(ch==3):
    print(num1,"*",num2,"=",mult(num1,num2))
elif(ch==3):
    print(num1,"/",num2,"=",div(num1,num2))
else:
    print("invalid")
