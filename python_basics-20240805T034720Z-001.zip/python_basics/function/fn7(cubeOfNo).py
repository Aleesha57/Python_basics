def cube(num):
    num**=3
    return num
data=cube(2)
print(data)