#with argument and return type

def add(num1,num2):
    sum=num1+num2
    return sum
data=add(20,30)
print(data)
data1=add(10,1)
print(data1)
# add(2,5)
# print(add(2,3))