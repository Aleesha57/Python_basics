#find the factorial

def fact():
    num=int(input("enter the number:"))
    m=1
    mu=1
    while(m<=num):
        mu*=m
        m+=1

    print(mu)
fact()
print("****************************")
def fact1(num):
    m=1
    mu=1
    while(m<=num):
        mu*=m
        m+=1

    print(mu)
fact1(5)
print("****************************")
def fact2(num):
    m=1
    mu=1
    while(m<=num):
        mu*=m
        m+=1
    return mu

data=fact2(5)
print(data)