def div(num1,num2):
    d=num1/num2
    print(d)
div(10,2)
