# to avoid repetation
# ie we can reuse (reduce length of code
# 3 methods
#1.function without argument and no return type
#2.function with argument and no return type
#3.function with argument and return  type


#1.function without argument and no return type
def add():
    num1 = int(input("enter number 1:"))
    num2 = int(input("enter number 2:"))
    sum = num1 + num2
    print(sum)


add()
add()


#sytax
# def fname(arguments):
#     fn_definition='ali' #task
# #fn_call
# fname()
#