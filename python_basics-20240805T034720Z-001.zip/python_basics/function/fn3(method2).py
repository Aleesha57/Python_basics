#fun with argument and no return type

def add(num1,num2):
    sum=num1+num2
    print(sum)
add(30,20)
