def mult():
    num1=int(input("enter no1:"))
    num2=int(input("enter no2:"))
    num3=int(input("enter no3:"))
    multi=num1*num2*num3
    print(multi)
mult()
mult()
