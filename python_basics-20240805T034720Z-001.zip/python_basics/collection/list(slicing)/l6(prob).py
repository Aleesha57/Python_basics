list=[]
str='luminar'
count=0
vowels='aeiou'
for i in str:
    if(i in vowels):
        count+=1
        list.append(i)
print(list)
print(count)
print(len(list))


