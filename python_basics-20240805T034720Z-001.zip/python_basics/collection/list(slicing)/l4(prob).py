list=[1,2,3,4,5,6,7,8,12]
print(list)
print(6 in list)  #true
print(55 in list) #false   present or not

print(2 not in list)  #false
print(55 not in list)  # ture