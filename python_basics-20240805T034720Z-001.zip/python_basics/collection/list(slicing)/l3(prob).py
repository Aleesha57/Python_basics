list=[1,15,12,7,9,45]
flag=0
num=int(input("enter the element:"))
for i in list:
    if(i==num):
        flag=1
        break
if(flag>0):
    print("found")
else:
    print("not found")

#linear search algorithm
