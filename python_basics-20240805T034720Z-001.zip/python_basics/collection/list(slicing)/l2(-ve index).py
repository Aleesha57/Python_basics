list=[1,15,2,3,14,12,5,8]

#negative  (right to left)

print(list[-1])