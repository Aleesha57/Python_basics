list=[1,12,5,14,85,23,5,44,62,7,16]

#index

print(list[3:7])   #start:stop
print(list[6:10])
print(list[4:6])

print(list[3:]) #stop-1
print(list[:6])
print(list[:3])  #start:stop=3-1

print(list[:])  #full list

print(list[2:7:2]) #start:stop-1:step
print(list[5:9:3])

print(list[4::2])
print(list[6::4])

print(list[:10:3])

print(list[::5])