list=[[101,'alisha','m',23,'bigdata',1000],
      [102,'anju','t',26,'python',2000],
      [103,'shiny','h',55,'sslc',10]]
print(list)

for i in list:
      print(i[1])

      #age above 28
print("******************************************")
for i in list:
      if(i[3]>28):
            print(i)
print("****************")
for i in list:
      if(i[3]>29):
            print(i[1:5])
print("****************")
#prof=bigdata  fname,lname,age

for i in list:
      if(i[4]=='sslc'):
            print(i[1:4])
print("****************")
#bigdata and age>29  fname,age salary

for i in list:
      if(i[4]=='bigdata' & i[3]>29):
            print(i[1::2])
print("****************")
#salary above 1750 and prof=python fname,lname ,age
for i in list:
      if(i[4]=='python' & i[5]>1750):
            print(i[1:4])
print("*******************************************")
#total salary
sum=0
for i in list:
     sum+=i[-1]
print(sum)



