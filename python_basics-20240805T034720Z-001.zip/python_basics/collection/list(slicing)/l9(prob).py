list=[15,25,30,20,80]
print(list[3]+list[-2]+list[-0])
print(list[-0])  #ie it will read as 0th index

print('*********************************************************')
lst=[1,2,9,7,6,4,3,6,8,9,11,12,10,7,6,5,4,3,2,6,8,9,10,11,9,7,6]


#lst1=[1,9,3,12,2,11]  #increace and decreace cheyyumbo eleemnt collect akkua

