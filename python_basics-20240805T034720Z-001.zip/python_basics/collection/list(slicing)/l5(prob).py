list=[]
str='luminar'
vowels='aeiou'
for i in str:
    if(i not in vowels):
        list.append(i)
print(list)


