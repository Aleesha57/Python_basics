#count number of consonents

str='luminar technolab'
list=[]
vowels='aeiou'
for i in str:
    if(i not in vowels):
        list.append(i)
print(list)
print(len(list))