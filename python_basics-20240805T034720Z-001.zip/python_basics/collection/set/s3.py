#set operations

#1.union
#2.intersection
#3.difference

set1={2,4,75,13,18,14,15,58}
set2={5,78,45,16,95,14,13,15,66}
set3=set1.union(set2)
print(set3)

print("***********************")

set4=set1.intersection(set2)
print(set4)

print("**************************")
set5=set1.difference(set2)
print(set5)