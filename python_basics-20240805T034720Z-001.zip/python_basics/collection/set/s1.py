#set
# if there is any values
st={1,2,3,10.5,'luminar',False}

#for empty set
set()

#1.support heterogenous data
print(st)
#2.insertion order is not preserved
#3.not support duplicate values
st1={1,2,2,3,True,False,0,1}
print(st1)
#4.set is mutable