st={2,3,54,5,23}

#to add new value   add()

st.add(25)
st.add(12)
print(st)

#st.add(1,14)

#to add multiple elements   update()

st.update([5,6,67])
print(st)

print(sum(st))

#remove elements  (difference between remove and discard----------->return if that elemnt is not present)
  #remove
st.remove(3)
print(st)

st.remove(105)
print(st)

st.discard(105)
print(st)

  #discard
st.discard(6)
print(st)
