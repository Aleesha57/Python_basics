#word cout problem

#cat,cat,rat,rat,bat,bat,cat,rat,bat
line='cat cat rat rat bat bat cat rat bat sat bat'
#line by line to word by word

data=line.split(" ")
print(data)

dic={}
#key       value
#cat         1+1=2+1=3
#rat         1+1=2.....
#bat         1+1=2+1=3...

for i in data:
    if(i not in dic):
        dic[i]=1 #cat 1,rat 1
    else:
        dic[i]+=1
print(dic)
