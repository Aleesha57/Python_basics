#to add ne key value pair
dic={'id':101,'fname':'vinay','lname':'t','age':23,'salary':12000}
dic['marks']=45
print(dic)

print('fname' in dic)
print('lnam' not in dic)

#to delete

del[dic['fname']]
print(dic)