#dictionary

#key value pair

#id:101,fname='alisha',lname='k',age=23,salary=45000
#key=id,fname,lname,age,salary
#values=101,alisha,k,23,45000

dic={}  #empty dictionary
print(type(dic))

dic1={'id':101,'fname':'alisha','lname':'t','age':'23','salary':4200}
print(dic1)

#1.support heterogeneous
#2.duplicate key not support but support duplicate value

dic2={'id':101,'fname':'alisha','lname':'t','age':'23','age':25,'mark':25}
print(dic2)
#3.insertion order preserved
#4.mutable