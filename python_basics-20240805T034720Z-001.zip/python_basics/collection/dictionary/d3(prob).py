dic={'id':101,'fname':'vinay','lname':'t','age':23,'salary':12000}

#id,101
#fname,alisha

for i in dic:
    print(i,",",dic[i])
