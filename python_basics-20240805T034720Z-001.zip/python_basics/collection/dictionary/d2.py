dic={'id':101,'fname':'vinay','lname':'t','age':23,'salary':12000}
print(dic)
print(dic['id'])
print(dic['fname'])


#update
#age===30

dic['age']=30

dic['salary']=15000

dic['salary']+=12
print(dic)