#tuples

tu=()
print(type(tu))
tu1=tuple()
print(type(tu1))

#heterogenious data support
tu2=(10,10.5,'luminar','True',1000,123456258)
print(tu2)

#support duplicate value

tu3=(10,10,2,5,2)
print(tu3)

#insertion order preserved

#immutable

tu4=(10,15,20,25,30,35,40,45,50)
tu4[2]=100
print(tu4)