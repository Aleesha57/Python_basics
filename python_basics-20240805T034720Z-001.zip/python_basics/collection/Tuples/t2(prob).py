tu=(10,15,20,25,30,35,40,45,50)

#update 30 to 150  and allso tuple is immutable
lst=list(tu)
print(lst)
lst[4]=150
tu1=tuple(lst)
print(tu1)
