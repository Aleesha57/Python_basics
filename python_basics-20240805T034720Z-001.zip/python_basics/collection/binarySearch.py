#binary search algorithm
#1.sort in ascending
#2.low=0  upp=length-1
#3.calculate the mid value  low_upper//2
#4.searching element>list[mid]   low=mid+1
#5.sarching <mid   upp=mid-1
#6.search==mid  found

list=[6,7,8,9,12,45,6,3,25]
list.sort()
low=0
upp=len(list)-1
flag=0

s=int(input("enter the element:"))
while(low<=upp):
    mid = (low + upp) // 2
    if(list[mid]==s):
     flag=1
     break
    elif(s<list[mid]):
     upp=mid-1
    elif(s>list[mid]):
     low=mid+1
if(flag>0):
    print("element found", s)
else:
    print("not found")

