list=[]
for i in range(1,51):
    list.append(i)
print(list)

list1=[]
list2=[]
for j in list:
    if(j%2==0):
        list1.append(j)
    else:
        list2.append(j)
print(list1)
print(list2)