list=[5,50,1,14]

#(insert) to add elements in an exact position

list.insert(1,41)
print(list)

lst=[5,6,8,12,25]
# to remove the elements  (remove)
    #at a time single element
lst.remove(12)
print(lst)

#pop -to remove last element

lst.pop()
print(lst)

list.pop(3)  #3 =index not elemnt
print(list)


#find to remove multiple elements??