list=[10,11,12,13,14,15,16]

list1=[]
for i in list:
    j=i**2
    list1.append(j)
print(list1)