list=[10,20,1]

#to add new elements to the list

#append
list.append(50)
list.append(100)
print(list)


# to add multiple elemnts at a time (extend)
list.extend([1,20,30])
print(list)
