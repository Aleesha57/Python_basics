list=[5,6,7,8,9,10,11,12,13]
list1=[]
j=1
for i in list:
     list1.append(i**j)
     j+=1
print(list1)