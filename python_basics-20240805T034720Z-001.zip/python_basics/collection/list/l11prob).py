list=[1,55,14,33,6,12]

list.sort(reverse=True)
print(list)
print(list[1])