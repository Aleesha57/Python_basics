list=[1,2,4,12,45,2,17,3,9,5]
for i in list:
    print(i)