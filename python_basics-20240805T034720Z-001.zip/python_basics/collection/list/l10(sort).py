list=[10,11,50,18,44,61,3,4]

#to sort a list (sort)

list.sort()    #ascending order
print(list)

list.sort(reverse=True)
print(list)