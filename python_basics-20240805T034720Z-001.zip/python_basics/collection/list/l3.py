#total sum
list=[1,2,3,4,5,6]
sum1=0
for i in list:
    sum1+=i
print(sum1)

#sum function
print(sum(list))
#max
print(max(list))
#min
print(min(list))
#total number of elements(len)
print(len(list))