list=[]
for i in range(1,101):
     list.append(i)
print(list)



list2=[]
for i in range(1,101):
    if(i%2==0):
        list2.append(i)
print(list2)