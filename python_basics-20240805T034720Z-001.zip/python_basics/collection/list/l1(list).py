#represent using square bracket

list1=[]  #empty list
print(type(list1))

#ist function
lst=list()
print(type(lst))

list2=[1,2,3,4,5,6]
print(list2)

#support heterogenious data

list3=[1,4.5,464968789,'luminar']
print(list3)

#duplicate value support
ist4=[2,1,2,3,4,4]
print(ist4)

#insertion order preserved

list5=[31,4,2,8,3]
print(list5)

#mutable

list6=[1,2,5,7,10,5]
print(list6[2])  #index

#10=======>100
list6[4]=100
print(list6)