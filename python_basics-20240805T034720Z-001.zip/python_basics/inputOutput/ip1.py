#input function
num1=10
name='luminar'
num=input("enter number")
print(num)