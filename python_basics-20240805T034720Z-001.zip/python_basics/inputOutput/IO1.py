# my name is sabir
# coming from kannur
# qualification msc
print("my name is alisha")
print("coming from kannur")
print("qualification is msc computer science")