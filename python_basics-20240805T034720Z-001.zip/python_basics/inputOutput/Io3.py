name='alisha'
age=23
fav_clr='blue'
print(name,age,"years old likes",fav_clr,"colour")