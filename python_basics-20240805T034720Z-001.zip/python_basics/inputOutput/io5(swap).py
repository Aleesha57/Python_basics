#without using 3rd variable
num1=5
num2=6
print("before swaping",num1,num2)
num1=num1+num2
num2=num1-num2
num1=num1-num2
print("after swaping ",num1,num2)
