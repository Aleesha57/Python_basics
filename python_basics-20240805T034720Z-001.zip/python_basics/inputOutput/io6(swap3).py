#method3 single line swaping

a,b,c,d=1,52,23,3
print(b)
num1,num2=10,20
print("before swaping ",num1,num2)
num1,num2=num2,num1
print("after111111 swaping ",num1,num2)