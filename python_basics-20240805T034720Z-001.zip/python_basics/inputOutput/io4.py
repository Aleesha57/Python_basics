num1=10
num2=20
print("before swap numbers are",num1,num2)
temp=num1
num1=num2
mum2=temp
print("after swap numbers are",num1,num2)