#logical op

# 1.AND   &
# 2.OR    |
# 3.XOR   ^
#        AND  OR   XOR
# 0   0   0    0    0
# 0   1   0    1    1
# 1   0   0    1    1
# 1   1   1    1    0

num1=2    #binary=0010
num2=4    #binary=0100

                # 0000  so ouput=0
print(num1&num2)

num3=6
num4=5
print(num3&num4)
print(num3^num4)
print(num3|num4)
