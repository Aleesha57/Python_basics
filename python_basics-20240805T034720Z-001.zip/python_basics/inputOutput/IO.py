#output_fn
   #print()
print("hello")