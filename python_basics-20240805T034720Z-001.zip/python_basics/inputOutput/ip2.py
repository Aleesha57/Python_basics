#company name,location,

company=input("enter the company name")
location=input("enter the location")
print(company,"is located at",location)