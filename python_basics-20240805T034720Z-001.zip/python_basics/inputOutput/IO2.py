company_name='luminar'
location='kakkanad'
print(company_name)
print(location)
#institution name is luminar
print("institution name is",company_name)
#institution located at kakkand
print("institutio located at",location)
print(company_name,"is IT finishing school located at",location)