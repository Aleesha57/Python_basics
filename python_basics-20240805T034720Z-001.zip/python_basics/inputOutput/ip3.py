name=input("enter the name")
age=input("enter the age")
fav_clr=input("enter the clr")
print(name,age,"yars old likes",fav_clr)