#banking problem

#bank name
#acc_no
#name
#min_balance

#deposite
#cash

#withdraw cash

class Bank:
    bank_name='canara'
    def setvalue(self,ac_no,name):
        self.name=name
        self.ac_no=ac_no
        self.minbalance=5000
        self.total=self.minbalance
    def Deposit(self,cash):
        self.cash=cash
        self.total=self.total+self.cash
        print("your",Bank.bank_name,"acc has been credited",self.cash,"total balance is ",self.total)
    def Withdraw(self,cash1):
        self.cash1=cash1
        if(self.total>=self.cash1):
            self.total=self.total-self.cash1
            print("your",Bank.bank_name,"acc has been debited",self.cash1,"total balance is",self.total)
        else:
            print("insufficient balance")
obj=Bank()
obj.setvalue(123586,'ali')
obj.Deposit(2000)
obj.Withdraw(3000)

