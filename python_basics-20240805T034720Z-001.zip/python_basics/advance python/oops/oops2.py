class Person:
    #def setvalue(self, fname, lname, age, place, salary):
    def setvalue(self,fname,lname,age,place):
        self.first_name=fname
        self.lname=lname
        self.age=age
        self.loc=place
    def printvalue(self):
        print(self.first_name)
        print(self.lname)
        print(self.age)
        print(self.loc)
        #print(salary)  #if it is instance vaariabe we can use it in another method
person1=Person()
person1.setvalue('vinay','s',27,'kochi')
person1.printvalue()
person2=Person()
person2.setvalue('alisha','th',23,'kannur')
person2.printvalue()