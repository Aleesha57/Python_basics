class Person:
    def reading(self):  # method  ,self=instance keyword-to create instance variable
       print("readig book")  # instance_keyword:this same variable can be use in next method
    def writing(self):
        print("writting books")

obj1=Person()  #object name should be same as class name
obj1.reading()
obj1.writing()