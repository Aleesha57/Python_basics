#persoal_data
#profisional_data

#fname,lname,age,location
#professional_data  :id,prof,salary
#id,fname,lname,age,prof,location,salary
#id,prof,salary

class personal_data:
    def setvaluea(self,fname,lname,age,location):
        self.fname=fname
        self.lname=lname
        self.age=age
        self.location=location



class professional_data(personal_data):
    def setvalueb(self,id,prof,salary):
        self.id=id
        self.prof=prof
        self.salary=salary
    def printsetvalueb(self):
       print (self.id,self.fname,self.lname,self.age,self.prof,self.location,self.salary)
obj1=professional_data()
obj1.setvalueb(101,'teacher',2000)
obj1.setvaluea('ali','t','age','kannur')
obj1.printsetvalueb()
