#student
#id,fname,lname,age,course,college_name

#performance
#sub1_mark,sub2_mark,sub3_mark,grade

#id,fname,lname,age,course,sub1,sub2,sub3,grade,college

class Student:
    coll="nirmala"
    def setvalue(self,id,fname,lname,age,course):
        self.id=id
        self.fname=fname
        self.lname=lname
        self.age=age
        self.course=course
class Performance(Student):
    def setvalue1(self,sub1,sub2,sub3,grade):
        self.sub1=sub1
        self.sub2=sub2
        self.sub3=sub3
        self.grade=grade
    def printsetvalue1(self):
        print(self.id,self.fname,self.lname,self.age,self.course,self.sub1,self.sub2,self.sub3,self.grade,Student.coll)

obj1=Performance()
obj1.setvalue(102,'ali','t',21,'bigdata')
obj1.setvalue1(21,23,43,'A')
obj1.printsetvalue1()
