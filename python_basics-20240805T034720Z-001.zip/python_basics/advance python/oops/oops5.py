#employee
#id,fname,lname,age,prof,sala,comp_name

class Employee:
    comp='tata'
    def setvalue(self,id,fname,lname,age,prof,salary):
        self.id=id
        self.fname=fname
        self.lname=lname
        self.age=age
        self.prof=prof
        self.salary=salary
    def printvalue(self):
        print(self.id)
        print(self.fname)
        print(self.lname)
        print(self.age)
        print(self.prof)
        print(self.salary)
        print(Employee.comp)
        print("\n")
emp1=Employee()
emp1.setvalue(101,'anu','p','45','developer',50000)
emp1.printvalue()

emp1=Employee()
emp1.setvalue(102,'manu','g','25','tester',45000)
emp1.printvalue()

emp1=Employee()
emp1.setvalue(103,'sugu','p','30','developer',20000)
emp1.printvalue()
