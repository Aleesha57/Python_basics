#construvtor

#class
  #we use constructor instead of method

#class
   #constructor
#object(values)

class Person:
    def __init__(self,fname,lname,age,phno):
        self.fname=fname
        self.lname=lname
        self.age=age
        self.phno=phno

    def printvalue(self):
        print(self.fname,"\n",self.lname,"\n",self.age,"\n",self.phno,"\n")
person1=Person('alisha','t',23,36464652)
person1.printvalue()
person2=Person('anu','k',52,5983)
person2.printvalue()