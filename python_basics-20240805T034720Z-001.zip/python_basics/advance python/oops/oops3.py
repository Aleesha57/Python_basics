#student:id,fname,lname,age,course,college_name
#5 objects

#2 typesof variable
   #1.static
   #2.instance variable or dynamic variable

class Student:
    def setvalue(self,id,fname,lname,age,collg):
        self.id=id
        self.fname=fname
        self.lname=lname
        self.age=age
        self.collg=collg
    def printvalue(self):
        print(self.id)
        print(self.fname)
        print(self.lname)
        print(self.age)
        print(self.collg)
        print("\n")
obj1=Student()
obj1.setvalue(101,'alisha','t',22,'raj')
obj1.printvalue()
obj2=Student()
obj2.setvalue(102,'anju','t',26,'kmm')
obj2.printvalue()
obj3=Student()
obj3.setvalue(103,'anitta','g',22,'raj')
obj3.printvalue()
obj4=Student()
obj4.setvalue(104,'shiny','t',21,'raj')
obj4.printvalue()
obj5=Student()
obj5.setvalue(105,'thomas','m',25,'raj')
obj5.printvalue()