#class person
   #fname,lname,sage

#employe
    #id,prof,salary
#class contact
   #ph,sex,location

#idd,fname,lname,age,prof,salary,ph,sex location

class Person:
    def setvalue(self,fname,lname,age):
        self.fname=fname
        self.lname=lname
        self.age=age
class Employe:
    def setvalue1(self,id,prof,salary):
        self.id=id
        self.prof=prof
        self.salary=salary
class Contact(Person,Employe):
    def setvalue2(self,ph,sex,location):
        self.ph=ph
        self.sex=sex
        self.location=location
    def printsetvalue2(self):
         print(self.id,self.fname,self.lname,self.age,self.prof,self.salary,self.ph,self.sex,self.location)
obj1=Contact()
obj1.setvalue2(935627,'f','kannur')
obj1.setvalue1(102,'teacher',20000)
obj1.setvalue('ali','t',21)
obj1.printsetvalue2()


