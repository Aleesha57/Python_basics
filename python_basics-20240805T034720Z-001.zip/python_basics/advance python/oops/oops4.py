#student:id,fname,lname,age,course,college_name
#5 objects
#all students are in same college
#2 typesof variable
   #1.static   (no change)
   #2.instance variable or dynamic variable(it will change)

class Student:
    coll='mes'  #static
    def setvalue(self,id,fname,lname,age,course):
        self.id=id
        self.fname=fname
        self.lname=lname
        self.age=age
        self.course=course

    def printvalue(self):
        print(self.id)
        print(self.fname)
        print(self.lname)
        print(self.age)
        print(self.course)
        print(Student.coll)
        print("\n")
obj1=Student()
obj1.setvalue(101,'alisha','t',22,'python')
obj1.printvalue()
obj2=Student()
obj2.setvalue(102,'anju','t',26,'bigdata')
obj2.printvalue()
obj3=Student()
obj3.setvalue(103,'anitta','g',22,'hadoop')
obj3.printvalue()
obj4=Student()
obj4.setvalue(104,'shiny','t',21,'bsc')
obj4.printvalue()
obj5=Student()
obj5.setvalue(105,'thomas','m',25,'bca')
obj5.printvalue()