#2 types of variable
#1.static variable(IT WILL NOT CHANGE)
#instance variable or dynamic variabale( it will change )

