string='luminartechnolab'
list1=[i for i in string if i in 'aeiou']
print(list1)