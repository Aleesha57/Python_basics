#list Comprehension

#all programs in list can do in a single line

#it didnt have any proper syntax

 #method1
 #method2
 #method3

 #method1
lst=[]
for i in range(1,51):
    lst.append(i)
print(lst)
print("\n*****************************************************************************************\n")
#var_name=[print range]
#1 to 30

lst1=[i for i in range(1,31)]
print(lst1)

print("\n**********************************************************************\n")

#1 to 25 elements sqr

lst2=[i**2 for i in range(1,26)]
print(lst2)

print("\n******************************************************************************\n")
lst3=[1,2,3,4,5,6]
#add 3

lst4=[i+3 for i in lst3]
print(lst4)