#map

#filter

#[1,2,5,4,7,83] ===>f(x) ====>[1,4,25,16,....]
#if we have a list and we want some other list corresponds to the elements the 1st list we use :map
#eg2:[ae,ab,ed,oh....]===f(x) ===>[AE,AB,ED,....]

#filter:if we have a condition to select the elements in the list

#eg:[1,2,3,4,5,6,7,8,9..] ==>f(x) ====>[2,4,6,8,...](even no.s)


#syntax

#variable_name=list(map(function,itrable))
#variable name=list(filter(function,itrable))

#map(function,itrable)

lst=[1,5,4,2,7,3,8]
#sqr of all elements
# def square(num):
#     return num**2
#
#
# f=list(map(square,lst))
# print(f)

f = list(map(lambda num:num**2, lst))
print(f)

#cube of  numbers
f1=list(map(lambda num:num**3,lst))
print(f1)

#find even numbers
# def evenNo(num1):
#     if(num1%2==0):
#         return num1
# f3=list(filter(evenNo,lst))
# print(f3)

f3=list(filter(lambda num:num%2==0,lst))
print(f3)