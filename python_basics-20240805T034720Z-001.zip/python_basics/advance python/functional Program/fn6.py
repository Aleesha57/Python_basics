#method2

#1 to 25 even no.s

#[print range condition]

lst=[i for i in range(1,26) if i%2==0]
print(lst)

#1 to 50 odd numbers

lst2=[i for i in range(1,51) if i%2!=0]
print(lst2)

#1 to 30 even no squre (2,4) ie (element,sqr)

lst3=[(i,i**2) for i in range(1,31) if i%2==0]
print(lst3)

#1 to 100 div by 5

lst4=[i for i in range(1,101) if i%5==0]
print(lst4)

#1 to 10  ==(1,1,2),(2,4,3),(3,9,4),(4,16,5),.....

lst5=[(i,i**2,i+1) for i in range(1,11)]
print(lst5)