#functional programming
#modern approch :to minimize the length of code


#1.lambda
#2.map
#2.filter
#3.list-comprehension

#lambda:anonymous function
  #sum of 2 numbers
def add(num1,num2):
    sum=num1+num2
    return sum
data=add(5,2)

f=lambda  num1,num2:num1+num2
print(f(20,50))
 #syntax
   #variable name=lambda arguments:operation