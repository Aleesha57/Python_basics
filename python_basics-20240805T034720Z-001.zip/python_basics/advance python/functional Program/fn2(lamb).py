#mult of 3 no and square of a number
f=lambda a,b,c:a*b*c
print(f(5,2,2))


f=lambda a:a**2
print(f(5))