#problems

lst=[5,6,7,8,9,10]
#1.create a identical list (exact list)
#2.each element add by 2
#3.square value above 50 data print

f=[i for i in lst]
print(f)

f1=[i+2 for i in lst]
print(f1)

f2=[i**2 for i in lst if i**2>50]
print(f2)

