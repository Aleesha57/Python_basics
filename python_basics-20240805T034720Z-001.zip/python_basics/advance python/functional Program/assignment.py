

#create a list 1 to 1000

lst1=[i for i in range(1,1001)]
print(lst1)

#2.find all of the numbers from 1 to 100 that are divisile by  8

print("\n***************************************************************\n")

lst2=[i for i in range(1,101) if i%8==0]
print(lst2)

#3.find all of the numbers from 1 to 1000 that have 6 in them

print("\n***************************************************************\n")
lst3=[i for i in range(1,1001) if '6' in str(i)]
print(lst3)

#4.count number of spaces in string
string='Practice problems to drill list comprehension in your head'

print("\n***************************************************************\n")
lst8=len([i for i in string if i==' '])
print(lst8)
lst4=sum([1 for i in string if i==' '])
print(lst4)

#5.count number of vowels in a string

print("\n***************************************************************\n")
lst5=sum([1 for i in string if i in 'aeiou'])
print(lst5)

#6.remove all of the vowels in a string

print("\n***************************************************************\n")

lst6=''.join([i for i in string if i not in 'aeiouAEIOU'])
print(lst6)
print(string)

#7.find all of the word in a string that are lsess than 5 letters

print("\n***************************************************************\n")

lst7=[i for i in string.split(" ") if len(i)<5]
print(lst7)



