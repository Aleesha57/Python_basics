#method3
#more than one condition

#if elis else.....

#here the is only if else
# 1 to 30 even_sqr odd cube
#[print if condition1 else print2 range]
#[print if condition1 else print2 if condition2 else print3 range]

#1 to 50 elements even sqr odd cube
#elements (1,1),(2,4),(3,27),....)

f=[(i,i**2) if i%2==0 else (i,i**3) for i in range(1,51)]
print(f)

#1 to 30 even===even odd==odd (1,odd),(2,even)....)
f1=[(i,'odd') if i%2!=0 else (i,'even') for i in range(1,31)]
print(f1)

string='luminartechnolab'
#if vowels preset y not n(l=n,u=y,m=n,....)
list=[(i,'n') if i not in 'aeiou' else (i,'y') for i in string]
print(list)