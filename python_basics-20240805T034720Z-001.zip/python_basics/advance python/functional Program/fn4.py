#odd num its square

lst=[1,2,3,4,5,6,7,8,9,10]

f=list(filter(lambda num:num%2!=0,lst))
f2=list(map(lambda num1:num1**2,f))
print(f2)