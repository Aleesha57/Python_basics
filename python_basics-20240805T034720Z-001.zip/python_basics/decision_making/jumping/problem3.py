a,b=10,15
if a+b:  #10+15=25  if we get an answer like non zero number  it is true -ve aanelum koyppula
    print("bad")
else:
    print("good")

for i in 'luminartechnolab':
    if(i=='r'):
        break
    print(i)


print("****************************")


for l in 'john':
    if l=='o':
        pass
    print(l,end=" ")

print("****************************")
x=0
a=0
b=-5
if a>0:
    if b<0:
        x=x+5
    elif a>5:
        x=x+4
    else:
        x=x+3
else:
    x=x+2
print(x)
