x=0
for i in range(10):
    for j in range(-1,-10,-1):
        x+=1
print(x)
