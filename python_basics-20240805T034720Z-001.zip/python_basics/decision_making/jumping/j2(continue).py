#continue
for i in range(1,51):
    if(i==25):
        continue   #nammal kodukkunna condition skip aakkitt bakki full varum
    print(i)