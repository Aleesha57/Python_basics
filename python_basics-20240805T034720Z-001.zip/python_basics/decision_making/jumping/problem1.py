for num in range(-2,-5,-1):
    print(num,end=" ")

#-2  -3 -4

