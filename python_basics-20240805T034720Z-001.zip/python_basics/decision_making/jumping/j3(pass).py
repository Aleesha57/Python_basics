for i in range(1,51):
    if(i==25):
        pass   ### do nothing
    print(i)

num=int(input("enter the number:"))
if(num%2==0):
    print("even")
else:
   pass