# salary
# experiance
# 5 yr more exp bonus =5% of sal

salary=int(input("enter the salary"))
exp=int(input("ente rthe experiance:"))
if(exp>5):
    print("bonus=",(salary*5)/100)
else:
    print("no bonus")