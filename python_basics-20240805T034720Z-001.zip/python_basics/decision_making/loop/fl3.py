lower=int(input("enter the lower:"))
upper=int(input("enter the upper"))

for i in range(lower,upper+1):
    print(i)