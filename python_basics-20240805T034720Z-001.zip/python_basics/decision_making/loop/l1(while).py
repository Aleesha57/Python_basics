#sytax

#1.initialization
#2.condition
#3.increment or decrement

#while

i=1   #initialization
while(i<=10):  #condition
    print("hello")
    i+=11111