#153================351
#153%10==3

   #153//10==15
# 15%10=5

    #15//10=1
# 1%10=1


num=int(input("enter the number:"))
rev=0
while(num!=0):
    digit=num%10
    rev=(rev*10)+digit
    num//=10
print(rev)
