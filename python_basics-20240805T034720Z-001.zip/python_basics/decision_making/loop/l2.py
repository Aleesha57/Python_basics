#1  to 25

i=1
while(i<=25):
    print(i)
    i+=1