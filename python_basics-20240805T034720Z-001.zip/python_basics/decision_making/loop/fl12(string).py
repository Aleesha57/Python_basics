for i in 'luminar':
    print(i)