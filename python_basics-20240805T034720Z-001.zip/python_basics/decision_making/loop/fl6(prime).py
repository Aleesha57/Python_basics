#2,5,7,11..........
#can only divided by that number and 1

#9  (2,3,4,5,6,7,8)

#19  (2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18)

num=int(input("enter the number:"))
flag=0
for i in range(2,num):
    if(num%i==0):
       flag=1
       break
if(flag>0):
    print("not prime")
else:
       print("number is prime")