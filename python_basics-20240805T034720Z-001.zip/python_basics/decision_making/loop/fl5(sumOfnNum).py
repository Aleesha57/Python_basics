num=int(input("enter the number:"))
sum=0
for i in range(num+1):
    sum+=i
print(sum)


###multiplication table,even/odd_sum
