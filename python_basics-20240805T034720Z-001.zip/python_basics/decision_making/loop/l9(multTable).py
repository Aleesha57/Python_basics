num=int(input("enter the number:"))
i=1
while(i<=10):
    print(i,"*",num,"=",(i*num))
    i+=1