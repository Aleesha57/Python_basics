up_no=int(input("enter the upper limit:"))
lwr_no=int(input("ente the lower limit:"))

while(lwr_no<=up_no):
    print(lwr_no)
    lwr_no+=1