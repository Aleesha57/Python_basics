for i in range(1,10):
    print("hello")   #(uppper limit-1) here upperlimit=10
                    #by default increment/decrement is 1

for i in range(1,10,2):
    print("hello")

#syntax
  #for i in range(lowerlimit,upperlimit,increment/decrement):
      # statement
for i in range(10): # if only one it will take as upperlimit and lower =0
    print(i)