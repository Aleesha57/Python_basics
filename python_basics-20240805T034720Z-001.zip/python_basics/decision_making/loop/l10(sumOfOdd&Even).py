lower=int(input("enter the lower number:"))
upper=int(input("eter the upper number:"))
even_sum=0
odd_sum=0
while(lower<=upper):
    if(lower%2==0):
        even_sum+=lower

    else:
        odd_sum+=lower
    lower += 1
print("odd sum=",odd_sum)
print("even sum=", even_sum)

