#30 to 0

i=30
while(i>=0):
    print(i)
    i-=1