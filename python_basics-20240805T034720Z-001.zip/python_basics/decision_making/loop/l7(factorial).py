num=int(input("enter the number:"))
i=1
mult=1
while(i<=num):
    mult*=i
    print(mult)
    i+=1
print(mult)