# 11
# 22
# 33
# 44
# 55

for i in range(1,6):
    for j in range(1,3):
        print(i,end=" ")
    print()