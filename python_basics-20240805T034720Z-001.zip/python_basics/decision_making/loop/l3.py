#10 to 50

i=10
while(i<=50):
    print(i)
    i+=5