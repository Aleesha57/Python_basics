#nested for loop
for i in range(1,5):
    for j in range(1,5):
        print(i)

for i in range(1,5):
    for j in range(1,5):
        print(i,end=" ")
    print()

# 1 1 1 1
# 2 2 2 2
# 3 3 3 3
# 4 4 4 4

#i====row
#j===column representation