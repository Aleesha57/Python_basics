#sum of n numbers
num=int(input("enter the number:"))

i=1
sum=0
while(i<=num): #1<=10  2<=10  3<=10......
    sum+=i  #0+1=1  1+2=3 3+3=6.......
    i+=1
print(sum)
