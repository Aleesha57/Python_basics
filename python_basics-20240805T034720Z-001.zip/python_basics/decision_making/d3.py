#given number +ve or -Ve

#if..elif...else
# syntax
# if(condition):
#     stmnt1
# elif(condi):
#     stmnt2
# elif(condi):
#     stmnt3
# else:
#     stmnt4

num=int(input("enter the number"))

if(num>0):
    print("it is +ve")
elif(num<0):
    print("it is -ve")
else:
    print("Zero")