sub1=int(input("enter the mark1"))
sub2=int(input("enter the mark2"))
sub3=int(input("enter the mark3"))
sub4=int(input("enter the mark5"))
total=sub1+sub2+sub3+sub4
print("total=",total)

if(total==180):
    print("A+")
elif(160<total<179):
    print("A")
elif(140<total<159):
    print("B+")
elif (total > 120 & total < 139):
    print("B")
elif (total > 100 & total < 119):
    print("C+")
elif (total > 80 & total < 99):
    print("C")
else:
    print("fail")