num1=int(input("enter the number 1"))
num2=int(input("enter the number 2"))
num3=int(input("enter the number 3"))
if(num1>num2 & num1>num3):
    print("largest=",num1)
elif(num2>num1 & num2>num3):
    print("largest=",num2)
else:
    print("largest=",num3)
