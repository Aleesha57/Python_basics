#if...else
# syntax
# if(condition):
#     stmnt1
# else:
#     stmnt2

age=int(input("enter your age"))
if(age>=18):
 print("you can vote")
else:
 print("you can't vote")
 #  :  means block