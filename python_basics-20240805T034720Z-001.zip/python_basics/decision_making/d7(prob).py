total=int(input("enter the total number of classes:"))
attended=int(input("enter the no.of attended class"))
percent=(attended/total)*100
if(percent<75):
    print("not allowed to write the exam")
else:
    print("allowed")