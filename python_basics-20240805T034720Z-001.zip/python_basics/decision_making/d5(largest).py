num=int(input("enter the number"))
num1=int(input("enter the 2nd number"))
if(num>num1):
    print("largest numberr is",num)
elif(num<num1):
    print("argest nmber is",num1)
else:
    print("same same")