Crnt_year=int(input('enter the current year:'))
crnt_mnth=int(input("enter the current month:"))
crnt_date=int(input("enter the current date:"))

birth_yr=int(input("enter the birth year:"))
birth_mnth=int(input("enter the birth mnth:"))
birth_date=int(input("enter the birth date"))

