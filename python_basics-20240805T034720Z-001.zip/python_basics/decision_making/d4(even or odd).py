num=int(input("enter the number"))
if(num%2==0):
    print("it is even")
else:
    print("odd number")