num1=int(input("enter the 1st number:"))
num2=int(input("enter the 2nd number:"))
num3=int(input("enter the 3rd number:"))

if(num1>num2)&(num1>num3):
    if(num2>num3):
        print("2nd largest number is:",num2)
    else:
        print("2nd largest number is:",num3)
elif(num2>num1)&(num2>num3):
    if(num1>num3):
        print("2nd largest number is:", num1)
    else:
        print("2nd largest number is:", num3)
elif(num3>num1)&(num3>num2):
    if(num1>num2):
        print("2nd largest number is:", num1)
    else:
        print("2nd largest number is:", num2)
else:
    print("equal")