#flow controls
   # 1.Decision making(if,if...else.if....elif..else)
   #  2.looopin(for,while)
   #  3.jumping(break,continue,pass)