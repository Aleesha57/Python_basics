#1.find row count
f=open('C:/Users/User/Downloads/movies','r')
for i in f:
    print(i)
#2.remove duplicates and find row count
#3.sort data set by release year in des order
#4.find ratig max 5 movies name year,rating
#5.find each year release movie count[count desc order
#6.find rating min 3 movies name year rating
#7.each rating count[count desc order
#8.2008 and rating above3[collect]
     #A.raw count
#9.find duration max 1 movies name, year rating durtaion
#10.find rating miin one movies "
#11.rating above 4 and release ye above 2005
    #A rating max movies full data
    #B rating min movies full data
#12.2008 movies count
#13.1975-2000 movies collect
  #A row count
#14.1975-2000 and rating above 3.5 total row count
