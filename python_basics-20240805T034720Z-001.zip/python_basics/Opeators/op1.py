#operators
# 1.arithemetic
# 2.logiccal
# 3.relational
# 4.compound assignment

#Arithemetic
# 1.addition
# 2.multiplication
# 3.substraction
# 4.division
# 5.modulus(to fetch remainder) eg:9%2=1,11%3=2
# 6.power ** 2**3=(2*2*2)
# 7.floor division (discard decimal)9//2=4 9/2=4.5
num1=int(input("enter the 1st number:"))
num2=int(input("enter the 2nd number:"))
sum=num1+num2
print("sum=",sum)

#console il ninnu input fn vazhi read akkiyal ath string aayitt aarikkum read akkua
    #(ie default string)