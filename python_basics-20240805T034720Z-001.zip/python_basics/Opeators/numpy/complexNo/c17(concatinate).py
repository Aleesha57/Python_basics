#join 2 array:concatinate

import numpy as np
a=np.array([2,4,5,56,7,62,12])
b=np.array([21,4,15,6,7,2,1])
c=np.concatenate((a,b))
print(c)