import numpy as np
a=np.array([1,3,4,5,7,11,12,14,78])
print(a)

print(a[2])
print(a[6:])
print(a[:])