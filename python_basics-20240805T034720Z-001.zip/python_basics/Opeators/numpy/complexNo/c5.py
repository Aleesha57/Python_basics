#1 to 20 5*4 matrics

import numpy as np
a=np.arange(1,21).reshape([5,4])
print(a)
b=a.reshape([5,4]) #or this

print("********************************************")
#1 to 30 6*5

c=np.arange(1,31).reshape([6,5])
print(c)
print("********************************************")
d=np.arange(1,11,2) #step or increment/decrement
print(d)
print("********************************************")
#5,10,15,....50  (5*2)

e=np.arange(5,51,5).reshape([5,2])
print(e)