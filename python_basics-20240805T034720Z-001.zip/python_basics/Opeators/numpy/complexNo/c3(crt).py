import numpy as np
a=np.array([[1+2j,5+4j],[3+3j,4+1j]])
print(a)