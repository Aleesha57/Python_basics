import numpy as np
a=np.array([[3,4,5],[45,6,7],[33,45,2]])
b=np.array([[3,12,5],[6,12,7],[3,4,21]])
print(a)

print("1.Addition")
#add
c=np.add(a,b)
print(c)
print("substraction")
#subtract
d=np.subtract(b,c)
print(d)
print("multiplication")
#multiply not dot product concept
e=np.multiply(a,b)
print(e)
print("division")
#divide
f=np.divide(a,b)
print(f)
print("square of matrice")
g=np.square(a)
print(g)
print("square root")
#sqrt
h=np.sqrt(b)
print(h)

print("trignometric functions")

# sin
# cos
# tan
# cosec
# sec
# cot