import numpy as np
a=np.array([[3,4,5,6],[23,45,6,7],[7,33,45,2],[3,4,7,9]])
print(a)
print("\n1.Slicing in 2D")
# [3,4,5,6]
# [23,45,6,7]
# [7,33,45,2]
# [3,4,7,22,9]
#slicing syntax in 2D
#[row,columns]

print(a[:2,:3])  #row=0,1  column=0,1,2
print("\n2.")
print(a[1:4,:3])
print("\n3.")
print(a[2:4,1:4])
print("\n4.")
print(a[:,2:4])
print("\n5.")
print(a[1:,:])
print("\n6.")
print(a[1:4:2,1:])
print("\n7.")
print(a[2::2,1::2])

print("***********************")
#zeroth column and zzeroth row
print(a[:,:1])#zeroth column
print(a[:,0])
print("zeroth row\n")
print(a[:1,:])#zeroth row
print(a[0,:])
