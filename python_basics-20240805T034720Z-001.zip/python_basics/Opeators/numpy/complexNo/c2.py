#full (4*4)---5 --->complex

import numpy as np
a=np.full([4,4],5,dtype=complex)
print(a)