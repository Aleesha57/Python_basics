import numpy as np
a=np.array([3,4,5,6,35,12,49,7,12])

b=np.max(a)
print(b)

#2D
c=np.array([[3,4,5,6],[23,45,6,7],[7,33,45,2],[3,4,7,9]])
d=np.max(c)
print(d)

#column vise row vise max
e=np.max(c,axis=1)
f=np.max(c,axis=0)
print(e)
print(f)

#same min
#argmin
#argmx
