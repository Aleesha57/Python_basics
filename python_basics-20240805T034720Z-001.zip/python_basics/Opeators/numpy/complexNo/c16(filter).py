import numpy as np
a=np.array([2,4,5,56,7,62,12])

print(a)
b=a>8
print(b)
c=a[b]
print(c)

#even no
d=a%2==0
e=a[d]
print(e)