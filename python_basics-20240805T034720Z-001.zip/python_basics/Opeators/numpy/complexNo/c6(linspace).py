#inspace

import numpy as np
a=np.linspace(1,10,5)
print(a)