import numpy as np
a=np.array([3,4,5,6,35,12,49,7,12])
print(a)
for i in a:
    print(i)  #to collect datas in 1D

print("\n2D array \n")

c=np.array([[3,4,5,6],[23,45,6,7],[7,33,45,2],[3,4,7,9]])
for i in c:
    for j in i:
        print(j)
        
print("\n 3D array itration")
d=np.array([[[3,4,5,6],[23,45,6,7],[7,33,45,2],[3,4,7,9]]])
for i in d:
    for j in i:
        for k in j:
            print(k)