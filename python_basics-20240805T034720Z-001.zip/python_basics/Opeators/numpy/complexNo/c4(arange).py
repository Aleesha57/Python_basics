
#arange ---to define range

#1 to 10
import numpy as np
a=np.arange(1,10)
print(a)