#where
import numpy as np
b=np.array([3,4,5,6,35,12,49,7,12])
a=np.array([[3,4,5,6],[23,45,6,7],[7,33,45,2],[3,4,7,9]])

y=np.where(b==3)
print(y)

#2D

x=np.where(a==4)  #index vise  0th row 1 th column presnt & 3rd row 1 th column
print(x)

j=np.where(a>2)  #a%2==1 etc...
print(j)
