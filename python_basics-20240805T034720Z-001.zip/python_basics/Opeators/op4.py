#compound assignment

num=10
num=num+1
print(num)
num+=1
print(num)
num+=5
print(num)
num/=2
print(num)