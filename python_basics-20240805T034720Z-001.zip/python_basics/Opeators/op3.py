#relational op
# <,>,<=,>=,==,!=

#here the output is true or false
num1=10
num2=20
print(num1>num2)
print(num1<num2)
print(num1!=num2)
print(num1==num2)
print(num1>=num2)
print(num1<=num2)

#true < false (ie 1<0)