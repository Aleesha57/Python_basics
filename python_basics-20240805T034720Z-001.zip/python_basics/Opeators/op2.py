#multiplication


num1=int(input(" enetr the number 1:"))
num2=int(input("enter the number 2:"))
num3=int(input("enter the number 3:"))
mult=num1*num2*num3
print("multiplication=",mult)